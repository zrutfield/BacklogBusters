<?php 
	require_once("header.php");
?>

<!--Obviously this is all placeholder; this would be filled with front-page content once it's actually decided what's worthy of being front-page content.-->

<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam cursus nibh elementum nibh condimentum, id congue odio varius. Pellentesque eleifend mauris quis dignissim dictum. Pellentesque consectetur dictum velit non accumsan. Aenean tempus orci odio, ut laoreet erat egestas nec. In eu tristique tortor. Cras in dictum magna. Morbi tempor at libero quis tincidunt. Etiam vulputate elit nec dui sodales luctus. Nulla facilisi.</p>

<p>Duis nisl nibh, aliquam ac tincidunt a, volutpat in justo. Cras sollicitudin blandit varius. Quisque euismod risus in lobortis vulputate. Cras purus turpis, fermentum ac diam sed, convallis malesuada sapien. Proin non condimentum ante. Vestibulum dapibus leo ut ipsum tempor, venenatis iaculis turpis vehicula. Curabitur pharetra non lacus at dignissim. Suspendisse lacinia vel lectus in maximus. Vivamus varius enim metus, non eleifend ante vehicula quis. Vivamus non purus finibus, fermentum velit ac, ultricies neque. Suspendisse et rutrum leo. Donec placerat congue rhoncus. Donec eget odio efficitur, tincidunt massa eget, posuere nulla. Donec mollis metus dui, sed suscipit massa rhoncus eu. Phasellus efficitur malesuada dolor at varius. Nam viverra ex turpis, nec laoreet ante euismod vel.</p>

<?php
	require_once("footer.php");
?>